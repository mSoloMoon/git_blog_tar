# PacmanBlue

Pacman is a flat and responsive design theme for [Hexo](http://zespia.tw/hexo/).

[Demo](http://youfei.github.io/) 


##Installation
###Install
```
$ git clone https://github.com/youfei/pacmanBlue.git themes/pacmanBlue
```
**Pacman requires Hexo 2.4.5 and above.** 
###Enable
Modify `theme` setting in blog folder` _config.yml` to `pacmanBlue`.
###Update
```
cd themes/pacmanBlue
git pull
```
**please backup your `_config.yml` file before update.** 
##Configuration

Modify settings in  `/themes/pacmanBlue/_config.yml`.

