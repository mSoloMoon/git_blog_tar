title: 月光独奏 
date: 2014-10-30 19:09:41
---

## 关于我

> 五分死磕，六分懒惰，七分勤奋，八分安静，九分思考，十分无趣。
> 理想化编程：预构 -> TDD -> 代码编写-> 重构 -> 自动化测试 -> 必要文档 -> 持续交付/反馈；

<br />

### 技能：Android

- 理解Android软件栈：Applications、Application Framework、Libraries & Android Runtime and Linux Kernel
-	基本运行机制：Zygote -> starts up a VM -> listening on a socket -> forking its prewarmed VM and a new child process -> app.  
- 理解Android虚拟机：Dalvik Virtual Machine(DVM) —— Dalvik executable file(DEX)
- 理解UI main主线程及其影响，以及ANR；
- 熟练使用相关机制进行屏幕适配；
- 熟练使用第三方库，如Okhttp、Volley等；
- 熟悉并能使用相关 Android Security 机制；
- 熟悉 Android 基本测试机制；
- 熟练使用以下机制及对象创作Android App：Activity [Fragment]、Service、Content Provider/SQLite、Broadcast Receiver/Intent、Notification、View (包括自定义)、Animation、web（html、css、javascript及其库）

***

目前计划技能补充（since 2014-10）：

> 熟练使用 Android 测试机制进行 TDD；
> 熟练使用 Voice Android 开发；
> 熟悉并能对 Android 进行渗透测试；
> 熟悉并能使用 Cocos2d-x 平台开发

<br />

### 技能：Java Web 之 Play！框架

To do

<br />

### 技能：Web 之 NodeJs

To do

