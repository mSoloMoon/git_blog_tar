title: 程序员日志 - 2014-10-31
date: 2014-10-31 13:17:24
categories: 程序员日志
tags:
	- IT问题录
---

就在昨天升级完Archlinux后，今天中午再次打开时，发现虚拟机无法连接外网；经过以下步骤：验证，排错，改正后，问题得以解决：

``` bash
$ systemctl status network.service		# 验证：找不到网卡ens33；
$ lspci -k		# 排错：确认网卡存在，其名称竟变为eno16777736（为何名称变化了？）
$ vim /etc/systemd/system/network-wireless@.service		# 改正：修正网卡名称
$ systemctl reload
$ systemctl restart network.service
```

***

午后，浏览：

> http://www.v2ex.com
> http://www.oschina.net/
> https://code.google.com/p/guava-libraries/wiki/GuavaExplained		# 初步了解：google guava


