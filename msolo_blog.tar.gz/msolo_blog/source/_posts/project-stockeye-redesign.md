title: Stockeye 项目重新设计指引
date: 2014-11-01 20:01:11
categories: project
tags:
	- 项目
	- 软件开发
	- 软件框架
---

> 将原先在软件中不可分割的包按功能、使用方式的思路重新设计，
> 可做成以第三方库为基准的组件有：股票的报价、股票的预警、股票的资产状况；股票的资讯；股票的图表库（基础K线图）；股票的聊天库；
> 可高度组件化、不可分割的组件有：股票的数据库设计及实现；股票的定制查询库；

### **库的设计**

1、关于股票报价、股票的预警、股票的资产状况

- 核心对象举例

``` java
StockPriceObjList stockPriceObjList = StockPriceObjList.getInstance();
stockPriceObjList.init();
stockPriceObjList.addStock();
stockPriceObjList.addStockArray();
StockPriceObj obj = stockPriceObjList.get(0);

class StockPriceObj {

	String sName;
	String sCode;
	boolean hasSettedAlert
	int alertPrice;
	long alertVolume;
	int curPrice;
	long curVolume;
	
}

```

<!-- more -->

- 股票报价重构使用示例：

``` java
String[] stocks = new String[]{"sz000002", "sz002024", "sh601299"};
StockPriceQuotationList stockPriceQuotationList = StockPriceQuotationList.getInstance();
stockPriceQuotationList.init(stocks);
String[] firstOriginalResult = stockPriceQuotationList.get(0);			// "sz000002"
stockPriceQuotationList.get(1);			// "sz002024"
String[] firstResultByDigital = stockPriceQuotationList.get(0).digital();
stockPriceQuotationList.get(0).percentage();
stockPriceQuotationList.get(0).from(20140104).digital();
String resultForSpeak = stockPriceQuotationList.speak(S_DIGITAL);			// S_PERCENTAGE
```

2、股票的图表库

- 该图表库目前专注于K线图；
- 该图表库需要结合外部基本交易数据，该数据暂定为ArrayList<String[]>对象；

3、股票的聊天库

- To do

4、股票的数据库设计

- 直接以SQLite为主进行搭建
- 可考虑Content Provider 或 框架
 
5、股票的定制查询库

- To do

