title: 持续集成之路 —— Stockeye CalendarStock 库开发实录
date: 2014-11-18 03:23:14
categories: project
tags:
	- Java
	- 软件开发
	- 持续集成
	- 项目
---

> **关键字 ：Jenkins、Gradle、JUnit、Jacoco、jar 包和库、TDD**

###库项目结构

``` bash
| build.gradle
| src
|   |- main
|         |- java/com/msolo/stockeye/calendarstock/UtilCalTime.java
|   |- test
|         |- java/com/msolo/stockeye/calendarstock/UtilCalTimeTest.java
```

###构建脚本（无 Jacoco）

``` groovy
apply plugin: 'java'
version = 0.1
repositories {
	mavenCentral()
}
dependencies {
	testCompile 'junit:junit:4.11'
}
task libJavadocs(type: Javadoc) {
	source = sourceSets.main.allJava
}
```

###Jenkins 项目配置（无 JaCoCo）

- 项目名称：android_stockeye_cal_lib
- 源码管理：https://github.com/mSoloMoon/android_stockeye_calendar_lib.git
- 构建触发器：Poll SCM -> * * * * *
- 构建步骤1：Invoke Gradle script -> Switch -> clean build javadoc
- 构建后操作1：Publish JUnit test result report -> XML -> **/build/test-results/*.xml
- 构建后操作2：Publish Javadoc -> build/docs/javadoc/

###持续集成（无 JaCoCo）

![项目首页](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_1.png)
![测试结果总结](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_2.png)

<!-- more -->

![控制台输出](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_3.png)
![Javadoc](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_4.png)
![工作空间](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_5.png)
![JUnit报告1](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_6.png)
![JUnit报告2](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_7.png)
![生成的Jar包](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_8.png)


###构建脚本（增加 JaCoCo）

``` groovy
// 增加的部分
apply plugin: "jacoco"
jacocoTestReport {
    group = "reporting"
    description = "Generate Jacoco coverage reports after running tests."
    reports {
        xml.enabled true
        html.enabled true
        csv.enabled false
    }
    //classDirectories = fileTree(dir: 'build/classes/main', include: 'com/thc/**')
    //sourceDirectories = fileTree(dir: 'scr/java', include: 'com/thc/**')
    additionalSourceDirs = files(sourceSets.main.allJava.srcDirs)
}
```

###Jenkins 项目配置（增加 Jacoco）

- 构建后操作3：Record JaCoCo coverage report
- 构建后操作4：E-mail Notification

###持续集成（增加 JaCoCo）

![项目首页](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_9.png)
![Code Coverage report](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_10.png)
![控制台输出](https://msolomoon.github.io/images/Project_android_stockeye_cal_lib_11.png)

