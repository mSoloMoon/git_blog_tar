title: Stockeye项目 - CalendarStock包（初步设计）
date: 2014-11-08 15:00:38
categories: project
tags:
	- 软件开发
	- 项目
---

### 预构

``` java
// class UtilCalTime
public int getIntCal(); 
public String getStrCal(); 
public String getCalFormat(); 
public String getTimeHHMMSS(); 
public String getTimeFormat(); 
public String getLatestDayOfStock(); 
public String[] getWorkdayArrayUtilNow(); 
public int getIntWeekday(); 
public String getWeekday(); 
public int getCountByTenSecond(); 
public boolean checkIsWorkday(); 
public String convertIntToCalFormat(); 
public int convertStrCalToInt(); 
public int getQuarterByMonth(); 
public int getWeekIndexOfYear(); 
public int getDateIndexOfYear();
```

<!-- more -->

### TDD

``` java
package com.msolo.stockeye.calendarstock;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for UtilCalTime
 *
 * @author yuezhi.msolo@outlook.com (kevin mSolo)
 */
public class UtilCalTimeTest {

		private UtilCalTime utilCalTime = UtilCalTime.getInstance();

    @Test
    public void testAssertClassSingleton() {
			UtilCalTime utilCalTimeAnother = UtilCalTime.getInstance();
			assertSame("should be same", utilCalTime, utilCalTimeAnother);
    }

		@Test
		public void testGetIntCal() {
			int intCal = utilCalTime.getIntCal(new GregorianCalendar());	
			int intCalTest = 20141108;
			testAssertEquals("should be equal", intCal, intCalTest);
		}

}
```

### Coding


### CI


### Document

