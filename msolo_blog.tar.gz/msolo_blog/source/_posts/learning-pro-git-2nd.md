title: 学习 Git（一）—— Pro Git 2nd
date: 2014-11-16 20:52:47
categories: 书籍
tags:
	- 持续集成
	- 软件开发
---

###起步

**Git 认知**

- Snapshots, Not Diff erences
- Nearly Every Operation Is Local
- Everything in Git is check-summed before it is stored and is then referred to by that checksum
- Git Generally Only Adds Data
- The Three States ：the Git directory, working directory, and the staging area
- Git 基本工作流程 ：增删改（working directory）-> 存储快照（staging area）-> 提交（Git directory）
- Git 文件状态 ：untracked、unmodified、modified、staged

**配置 Git**

> /etc/gitconfig ：every user，$ git config --system
> ~/.gitconfig  or  ~/.config/git/config ：specified user, $ git config --global
> .git/config ：specified repository, $ git config

``` bash
$ git config --global user.name "John Doe"
$ git config --global user.email johndoe@example.com
$ git config --global core.editor emacs		# 默认 vim
$ git config --list		# $ git config user.name
``` 

###实战（一）

- 新项目

``` bash
$ git init     # 在某个项目目录里初始化一个 Git working directory -> .git 目录
$ git add *.c  # 存储快照（staging area）
$ git commit -m 'initial project version'  # 提交
$ git remote add origin https://github.com/username/example.git
$ git push -u origin master
```

<!-- more -->

- 查看文件状态

``` bash
$ git status   # 查看文件状态, 简洁版 -> git status -s
 M README            # 修改但未存储快照
MM Rakefile          # 修改并已存储快照后，再次修改，both staged and unstaged
A  lib/git.rb        # 已存储快照
M  lib/simplegit.rb  # 修改并已存储快照
?? LICENSE.txt       # untracked
```

- 克隆已有的项目

``` bash
$ git clone https://github.com/libgit2/libgit2 mylibgit
```

- 忽略要处理的文件 ：在 .gitignore 中创建要忽略文件的正则表达式，其中 # 开头为注释

``` bash
$ cat .gitignore
*.[oa]   # 忽略 .o 或 .a 的文件
*~       # 忽略文件尾是 ~ 的文件
```

- 比较 ：$ git diff，$ git diff --staged，$ git diff --cached
- 跳过快照区步骤 ：Git 自动提交已经追踪到的但没有存储到快照区（git add）的新文件 -> $ git commit -a -m 'added new benchmarks'
- 删除文件

``` bash
$ rm grit.gemspec
$ git rm grit.gemspec
$ git rm --cached README  # 忽略处理该文件
```

- 更改文件

``` bash
$ git mv README.md README  # 等同于 mv README.md README -> git rm README.md -> git add README
```

- 查看日志

``` bash
$ git log
$ git log -p -2    # -p 显示每一次提交的差别， -2 显示最近2次提交的日志
$ git log --stat   # --stat 显示简略的统计信息
$ git log --pretty=oneline   # 格式化显示
$ git log --pretty=format:"%h - %an, %ar : %s"
%H    Commit hash                   %h    Abbreviated commit hash
%T    Tree hash                     %t    Abbreviated tree hash
%P    Parent hashes                 %p    Abbreviated parent hashes
%an   Author name                   %ae   Author e-mail
%ad   Author date (format respects the –date= option)
%ar   Author date, relative         %cn   Committer name
%ce   Committer email               %cd   Committer date
%cr   Committer date, relative      %s    Subject
$ git log --pretty=format:"%h %s" --graph   # 以更好的格式显示分支及合并的历史记录
$ git log --since=2.weeks    # 前2个礼拜，其格式接受：2008-01-15，2 years 1 day 3 minutes ago
$ git log --author=userOne
$ git log -Sfunction_name    # 显示上一次提交中增加或删除的函数索引 function_name
$ git log --grep="update"
```

- 撤消或重新提交

``` bash
$ git commit -m 'initial commit'
$ git add forgotten_file
$ git commit --amend
$ git reset HEAD CONTRIBUTING.md	# 删除快照
$ git checkout -- CONTRIBUTING.md # 恢复到上一次提交之后修改之前的文件
```

- Git 命令别名

``` bash
$ git config --global alias.co checkout
$ git config --global alias.br branch
$ git config --global alias.ci commit
$ git config --global alias.st status
$ git config --global alias.unstage 'reset HEAD --'
$ git config --global alias.last 'log -1 HEAD'
```

###与远程进行协作

- 添加远程仓库别名 : $ git remote add pb https://github.com/paulboone/ticgit
- 显示别名及其代表的URL ：$ git remote -v
- 通过别名获取仓库 ：$ git fetch pb
- 推送到远程仓库 ：$ git push origin master
- 检查远程仓库状态 ：$ git remote show origin
- 重命名远程仓库别名 ：$ git remote rename pb paul
- 删除别名 ：$ git remote rm paul

###为项目添加标签

> Git 使用两种类型的标签 ：轻量级的（lightweight）和带注解的（Annotated）
> 轻量级 ：为某次特别的提交而添加的标签
> 带注解 ：包含所有必要的信息，像是标签的作者、日期、电邮、注解和 GPG 等（更像是一次版本？）

- 列出标签 ：$ git tag，$ git tag -l 'v1.8.5*'  # 只列出1.8.5系列的版本
- 创建 Annotated 标签 ：$ git tag -a v1.4 -m 'my version 1.4'
- 列出标签信息 ：$ git show v1.4
- 创建 Lightweight 标签 ：$ git tag v1.4-lw
- 推送标签 ：$ git push origin v1.5，$ git push origin --tags （默认情况下，推送不包含标签）
- 签出某个标签的版本 ：$ git checkout -b version2 v2.0.0（切记，标签默认不会被推送） 




