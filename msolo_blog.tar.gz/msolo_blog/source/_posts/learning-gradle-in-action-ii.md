title: 学习 Gradle —— Java 下一代构建工具（二）
date: 2014-11-18 01:43:29
categories: java-android
tags:
	- Java
	- 持续集成
	- 软件开发
---

> **Gradle 构建生命期**
> 初始化阶段（initialization phase）：创建 Project 实例 ->
> 配置阶段（configuration phase）：constructs a model representation of the tasks ->
> 执行阶段（execution phase）

###Gradle 构建脚本精要

> Gradle 构建的原理 -> 基于 **DDD（domain-driven design）**进行建模。

**构建模块**

- 模块：项目（the Project interface）

``` groovy
// Build script conﬁguration
apply(options: Map<String,?>)
buildscript(conﬁg: Closure)
//
// Dependency management
dependencies(conﬁg: Closure)
conﬁgurations(conﬁg: Closure)
getDependencies()
getConﬁgurations()
//
// Properties
getAnt()
getName()
getDescription()
getGroup()
getPath()
getVersion()
getLogger()
setDescription(description: String)
setVersion(version: Object)
//
// File creation
ﬁle(path: Object)
ﬁles(paths: Object...)
ﬁleTree(baseDir: Object)
//
// Task creation
task(args: Map<String,?>, name: String)
task(args: Map<String,?>, name: String, c: Closure)
task(name: String)
task(name: String, c: Closure)
// 示例
setDescription("myProject")                       
println "Description of project $name: " + project.description
```

<!-- more -->

> 管理项目版本
> def projectVersion = new ProjectVersion()
> projectVersion.major = 0
> projectVersion.minor = 1
> projectVersion.release = false
> version = projectVersion

- 模块：任务（the Task interface）: 默认新创建的任务类型 -> org.gradle.api.DefaultTask，private

``` groovy
// Task dependencies
dependsOn(tasks: Object...)
//
// Action deﬁnition
doFirst(action: Closure)
doLast(action: Closure)
getActions()
//
// Input/output data declaration
getInputs()
getOutputs()
//
// Properties
getAnt()
getDescription()
getEnabled()
getGroup()
setDescription(description: String)
setEnabled(enabled: boolean)
setGroup(group: String)
// 清理任务
task first << { println "first" }
task second << { println "second" }
first.finalizedBy second 	// 执行完或单独执行任务 first 后会触发任务 second（由它进行清理）
// 配置 : 其定义中没有 Action 或其缩写 <<
ext.versionFile = file('version.properties')   
task loadVersion {                     
   project.version = readVersion()
}
ProjectVersion readVersion() {
   logger.quiet 'Reading the version file.'
   if(!versionFile.exists()) {
      throw new GradleException("Required version file does not exist: $versionFile.canonicalPath") 
   }
   Properties versionProps = new Properties() 
   versionFile.withInputStream { stream ->  
      versionProps.load(stream)
   }
   new ProjectVersion(versionProps.major.toInteger(), 
       versionProps.minor.toInteger(), versionProps.release.toBoolean())
}
// 声明任务的输入和输出
task makeReleaseVersion(group: 'versioning', description: 'Makes project a release version.') {    
   // inputs 和 outputs 在配置阶段执行
   inputs.property('release', version.release)           
   outputs.file versionFile                
   doLast {
      version.release = true
      ant.propertyfile(file: versionFile) {
         entry(key: 'release', type: 'string', operation: '=', value: 'true')
      }
   }
}
```

- 自定义任务

``` groovy
class ReleaseVersionTask extends DefaultTask {                 
   @Input Boolean release                    
   @OutputFile File destFile                 
   ReleaseVersionTask() {
      group = 'versioning'                             
      description = 'Makes project a release version.' 
   }
   @TaskAction                       
   void start() {
      project.version.release = true
      ant.propertyfile(file: destFile) {
         entry(key: 'release', type: 'string', operation: '=', value: 'true')
      }
   }
}
task makeReleaseVersion(type: ReleaseVersionTask) {     
   release = version.release           
   destFile = versionFile              
}
task createDistribution(type: Zip, dependsOn: makeReleaseVersion) {
   from war.outputs.files                            
   from(sourceSets*.allSource) {     
      into 'src'
   }
   from(rootDir) {
      include versionFile.name  
   }
}
task backupReleaseDistribution(type: Copy) {
   from createDistribution.outputs.files         
   into "$buildDir/backup"
}
task release(dependsOn: backupReleaseDistribution) << {
   logger.quiet 'Releasing the project...'
}
```

``` bash
├──  build
│     ├──  backup
│     │     └──  todo-webapp-0.1.zip
│     ├──  distributions
│     │     └──  todo-webapp-0.1.zip
│     └──  libs
│         └──  todo-webapp-0.1.war
├──  build.gradle
├──  src
└──  version.properties
```

- 额外属性（extra properties）: 使用 ext 命名空间

``` groovy
project.ext.myProp = 'myValue'      
ext {                               
   someOtherProp = 123
}
assert myProp == 'myValue'              
println project.someOtherProp           
ext.someOtherProp = 567
```

- Gradle 属性单独定义示范

``` groovy
// 文件：gradle.properties
exampleProp = myValue
someOtherProp = 455
// 文件：build.gradle
assert project.exampleProp == 'myValue'
task printGradleProperty << {
   println "Second property: $someOtherProp"
}
// 命令行 ：-P 项目属性；-D 系统属性
// 环境属性 ：ORG_GRADLE_PROJECT_propertyName=someValue
```

###任务规则（Task Rule）



###


###


To do


